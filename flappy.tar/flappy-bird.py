
"""
    Description: Our verison of the world-reknown game flappy bird!
    Uses our pipe & bird classes (pipe.py, bird.py, respectively)
    Author: Aiden A. & Victor J.
    Date: Spring 2022
"""
# utilities graphics
from random import randrange
from graphics import *
from time import sleep

# custom classes
from pipe import *
from bird import *

#------------------------------------------------------------------------------#
def highScore(win, newScore, textSize):
    """
    Purpose: Function that determines whether a score is a highscore, writes to a
    txt file if it is, and displays the results of the game
    Parameters: The ongoing window object, the user's score, and the previously-
    calculated text size
    Returns: None
    """

    with open("highscore.txt", "r+") as f:
        # For some reason putting just a 0 made the file appear null, so 's were
        # added around the 0s (i.e., '0' instead of simply 0)
        highscoreInt = int(f.read().replace("'", ""))
        textWidgetWidth = win.getWidth() * .5
        textWidgetHeight = win.getHeight() * .53

        if highscoreInt < newScore:
            # Seeking and truncating clear file instead of reopening it with "w"
            f.seek(0)
            f.truncate(0)
            f.write("'" + str(newScore) + "'")

            highScoreText = Text(Point(textWidgetWidth, textWidgetHeight), "You set a new high score!")

        else:
            highScoreText = Text(Point(textWidgetWidth, textWidgetHeight), "High Score: %s" % (highscoreInt))

        highScoreText.setSize(textSize)
        highScoreText.draw(win)

    return

#------------------------------------------------------------------------------#
def welcomeScreen(window, width, height, textSize):
    """
    Purpose: To display a welcome screen before the game commences
    Parameters: The window object, height, width, and text size measurements /
    calculations for facility
    Returns: None
    """

    # Welcome string
    welcomeString = "Welcome to Faby Bird!"
    welcomeText = Text(Point(width*0.5, height*0.33), welcomeString)
    welcomeText.setSize(textSize)
    welcomeText.draw(window)

    gameInstructions = "Press the up arrow to stay\nin the air as long as possible\n"
    gameInstructions += "and avoid the pipes!"
    gameInstructions = Text(Point(width*0.5, height*0.43), gameInstructions)
    gameInstructions.setSize(textSize)
    gameInstructions.draw(window)

    # Initial instructions
    instructionsString = "Click anywhere to commence\nthe experience, the game will\n"
    instructionsString += "begin after a short countdown.\nGood luck!"
    initialInstructions = Text(Point(width*0.5, height*0.7), instructionsString)
    initialInstructions.setSize(textSize)
    initialInstructions.setFill("red")
    initialInstructions.draw(window)

    window.getMouse()

    # undrawing all instructions
    welcomeText.undraw()
    gameInstructions.undraw()
    initialInstructions.undraw()

    # initializing timer text field
    timerCountdown = Text(Point(width*0.5, height*0.5), "3")
    timerCountdown.setSize(textSize)
    timerCountdown.draw(window)

    # timer countdown
    for i in range(1, 0, -1):
        timerCountdown.setText(str(i))
        update(60)
        sleep(1)

    timerCountdown.undraw()

#------------------------------------------------------------------------------#
def main():
    """
    Purpose: The main driver of our flappy bird game—this is where the magic happens,
    where our pipe & bird objects are drawn and continuously animated in a while
    loop, and most of the game logic occurs
    Parameters: None
    Returns: None
    """
    # defining window settings
    window = GraphWin("Faby Bird", 900, 600, autoflush = False)
    window.setBackground("white")
    width = window.getWidth()
    height = window.getHeight()

    # defining game constants
    gravity = 0
    score = 0
    size = height*0.03
    textSize = int((108 * height) / ((3 * height) + 1000)) # cool way of calculating
    # the text size; making sure the asymptote is 36 so we never get a "text size too large" error
    fabyMovementGradient = 0.01
    pipeMovementGradient = 0.01
    gravityGradient = 0.5

    # welcome screen before the user begins the game
    welcomeScreen(window, width, height, textSize)
    window.setBackground("lightblue")

    # instantiating game objects
    faby = Bird(window, size)

    pipeobj = Pipe(window, None)
    pipeobj2 = Pipe(window, None)
    pipeobj2.move(width*0.5)
    pipeObjs = [pipeobj, pipeobj2]

    scoreText = Text(Point(width*0.5, height*0.1), score)
    scoreText.setSize(textSize)
    scoreText.draw(window)

    while True:
        update(60)
        gravity += gravityGradient

        # Pipe movement
        for i in range(len(pipeObjs)):
            pipeobject = pipeObjs[i]
            # removing pipe if it has gone off screen
            if pipeobject.offScreen() == True:
                for pipe in pipeobject.pipes:
                    pipe.undraw()

                pipeObjs[i] = Pipe(window, pipeobject.getTopY())

            pipeobject.move(-width*pipeMovementGradient)

            # slightly increasing the pipes' speed for added difficulty
            pipeMovementGradient *= 1.00015

            # Update score
            if faby.beyondPipe(pipeobject, pipeMovementGradient):
                score += 1
                scoreText.setText(score)

            # End game
            if faby.onScreen() == False or faby.isTouching(pipeobject):
                # creating gameover texts
                gameoverText = Text(Point(width*0.5, height*0.33), "Game Over :(")
                gameoverText.setSize(textSize)
                gameoverText.draw(window)

                scoreText.move(0, height*0.33)
                scoreText.setText("Score: %i" %(score))

                directions = Text(Point(width*0.5, height*0.8), "Click anywhere to exit")
                directions.draw(window)
                directions.setFill("red")
                directions.setSize(textSize)

                # updating / displaying the high score
                highScore(window, score, textSize)

                update(30)
                window.getMouse()
                return

            else:
                # Faby movement
                if window.checkKey() == "Up":
                    # Done instead of moving because it results in a clean "bounce" instead
                    # of a choppy jump
                    gravity = -height * fabyMovementGradient
                else:
                    faby.move(gravity)

main()
