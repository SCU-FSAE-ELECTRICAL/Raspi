
"""
    Description: Defines a class for a pipe object to be used in our version of
    flappy bird (flappy-bird.py)
    Author: Aiden A. & Victor J.
    Date: Fall 2022
"""
from random import randrange
from graphics import *

class Pipe(object):
    """ create pipe object that handles bird collision and movement """

    def __init__(self, win, previousTopLength):
        """ the constructor for our pipe object; takes only a valid window object """
        width = win.getWidth()
        height = win.getHeight()

        # useful pipe measurements
        pipeWidth = width * 0.05
        gapLeniencyGradient = 0.17
        if previousTopLength:
            newUpperBound = previousTopLength - (height * gapLeniencyGradient)
            if newUpperBound <= 0:
                newUpperBound = 1

            newLowerBound = previousTopLength + (height * gapLeniencyGradient)
            if newLowerBound > height * .8:
                newLowerBound = height * .8

            topPipeLength = randrange(int(newUpperBound), int(newLowerBound))

        else:
            topPipeLength = randrange(int(height * 0.17), int(height * 0.83))
        pipeGap = height * 0.17
        leftEdge = width - pipeWidth

        # creating our pipes
        topPipe = Rectangle(Point(leftEdge, 0), Point(width, topPipeLength))
        bottomPipe = Rectangle(Point(leftEdge, topPipeLength+pipeGap), Point(width, height))

        # saving them to a list for simplicity when rendering them (reference the below)
        self.pipes = [topPipe, bottomPipe]
        for pipe in self.pipes:
            pipe.draw(win)
            pipe.setFill("green")

    def __str__(self):
        """ affirming that the pipes exist """
        s = f"Pipes are active and exist"
        return s

    def move(self, dx):
        """
        Purpose: Moves a given pipe object a given integer in the x direciton
        Parameters: A pipe object, & an integer representing how much the pipe
        will move
        Returns: None
        """
        for pipe in self.pipes:
            pipe.move(dx, 0)

        return

    def getLeftX(self):
        """
        Purpose: Gets the left edge coordinate of the pipes
        Parameters: A pipe object
        Returns: An integer representing the left edge coordinate of the pipes
        """
        return self.pipes[0].getP1().getX()

    def getRightX(self):
        """
        Purpose: Gets the right edge coordinate of the pipes
        Parameters: A pipe object
        Returns: An integer representing the right coordinate of the pipes
        """
        return self.pipes[0].getP2().getX()

    def getTopY(self):
        """
        Purpose: Gets the bottom coordinate of the top pipe
        Parameters: A pipe object
        Returns: An integer representing the lowest point on the top pipe
        """
        return self.pipes[0].getP2().getY()

    def getBottomY(self):
        """
        Purpose: Gets the top coordinate of the bottom pipe
        Parameters: A pipe object
        Returns: An integer representing the highest point on the bottom pipe
        """
        return self.pipes[1].getP1().getY()

    def offScreen(self):
        """
        Purpose: Checks if the right edge of the pipe has gone off screen
        Parameters: A pipe object
        Returns: A boolean representing whether or not the pipe is off screen
        """
        if self.getRightX() <= 0:
            return True
        else:
            return False

#------------------------------------------------------------------------------#
if __name__ == '__main__':
    win = GraphWin("testWin", 400, 600)
    win.setBackground("lightblue")

    testPipe = Pipe(win, None)

    while not testPipe.offScreen():
        testPipe.move(-10)
        print("pipe is moving left...")

    print("Stopped moving; we have hit the left edge of the screen")
    win.getMouse()
