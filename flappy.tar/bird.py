
"""
    Description: Creates a bird class to be used in our python remake of flappy
    bird
    Author: Aiden A. & Victor J.
    Date: Fall 2022
"""

from graphics import *

class Bird(object):
    """ creates a bird class using a Zelle graphics Window object """

    def __init__(self, win, size):
        """ construct the bird object, given window object and size value """
        self.win = win
        self.size = size

        # useful measurements
        width = win.getWidth()
        height = win.getHeight()
        halfHeight = height * 0.5
        quarterWidth = width * 0.25

        # Body
        body = Circle(Point(quarterWidth, halfHeight), size)
        body.setFill("yellow")

        # Eye
        eye = Circle(
                Point(
                    0.4 * size + quarterWidth,
                    halfHeight - 0.4 * size),
                0.3 * size)
        eye.setFill("white")
        pupil = Circle(Point(0.5 * size + quarterWidth, halfHeight - 0.45 * size), 0.1 * size)
        pupil.setFill("black")

        # Beak
        topBeakPoint = Point(quarterWidth + 0.9 * size, halfHeight - 0.4 * size)
        middleBeakPoint = Point(quarterWidth + size * 1.4, halfHeight - 0.2 * size)
        bottomBeakPoint = Point(quarterWidth + size, halfHeight)
        beak = Polygon(topBeakPoint, middleBeakPoint, bottomBeakPoint)
        beak.setFill("orange")

        # Wing
        rightMostWingPoint = Point(quarterWidth + (size*.4), halfHeight + (size*.15))
        leftMostWingPoint = Point(quarterWidth - (size*.6), halfHeight + (size*.4))
        wingCurvePoint1 = Point(quarterWidth - (size*.4), halfHeight + (size*.6))
        wingCurvePoint2 = Point(quarterWidth - (size*.2), halfHeight + (size*.65))
        wingCurvePoint3 = Point(quarterWidth + (size*.05), halfHeight + (size*.7))
        wingCurvePoint4 = Point(quarterWidth + (size*.1), halfHeight + (size*.6))
        wingPoints = [
                        leftMostWingPoint,
                        wingCurvePoint1,
                        wingCurvePoint2,
                        wingCurvePoint3,
                        wingCurvePoint4,
                        rightMostWingPoint
                    ]
        wing = Polygon(wingPoints)
        wing.setFill("lightyellow")

        self.bodyParts = [body, eye, pupil, beak, wing]
        for shape in self.bodyParts:
            shape.draw(self.win)

    def __str__(self):
        """ create string affirming Faby's existence """
        s = f"Faby is feeling good today"
        return s

    def move(self, dy):
        """
        Purpose: Moves all parts of the given bird object a given amount in the
        positive y direction.
        Parameters: A bird obejct, an integer representing the distance to travel
        per button press
        Returns: None
        """
        for shape in self.bodyParts:
            shape.move(0, dy)

        return

    def onScreen(self):
        """
        Purpose: Checks if the given bird object is on the screen, returning false
        if it is not
        Parameters: A bird object (self)
        Returns: A boolean representing whether or not the bird is on screen
        """
        if self.bodyParts[0].getCenter().getY() <= self.size or self.bodyParts[0].getCenter().getY() >= self.win.getHeight() - self.size:
            return False
        else:
            return True

    def isTouching(self, pipeobj):
        """
        Purpose: Checks if given bird object is colliding with the given pipe object
        Parameters: A bird object, a pipe object
        Returns: A bool representing whether or not the given bird object is
        touching the given bird object
        """
        # body coordinates
        bodyCenter = self.bodyParts[0].getCenter()
        if (bodyCenter.getX() + self.size >= pipeobj.getLeftX()
            and bodyCenter.getX() - self.size <= pipeobj.getRightX()
            and (bodyCenter.getY() <= pipeobj.getTopY() + self.size
            or bodyCenter.getY() >= pipeobj.getBottomY() - self.size)):
                return True
        else:
            return False

    def beyondPipe(self, pipeobj, pipeMovementGradient):
        """
        Purpose: Check if bird has moved beyond the closets pipe object and thus
        needs to increment the score +1
        Parameters: A bird object, A pipe object, the movement speed of the pipe
        Returns: A bool representing whether or not the given bird object is beyond
        the pipe
        """
        # defining measurements
        width = self.win.getWidth()
        bodyCenter = self.bodyParts[0].getCenter()
        bodyLeftEdge = bodyCenter.getX() - self.size

        if (pipeobj.getRightX() <= bodyLeftEdge and
                pipeobj.getRightX() > bodyLeftEdge - (width*pipeMovementGradient)):
            return True
        else:
            return False

#------------------------------------------------------------------------------#
if __name__ == '__main__':
    win = GraphWin("testWin", 400, 600)
    win.setBackground("lightblue")

    faby = Bird(win, 20)

    while faby.onScreen():
        faby.move(10)
        print('moving...')

    print("Stopped moving; we have hit the bottom of the screen")
    win.getMouse()
